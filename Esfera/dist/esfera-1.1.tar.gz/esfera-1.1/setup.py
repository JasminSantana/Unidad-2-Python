from setuptools import setup
setup(
    name='esfera',
    version=1.1,
    descripcion='This model calculate volume and area of sphere',
    author='JASM',
    email='sant.mar.1997@gmail.com',
    url='http://www.utng.edu.mx',
    py_modules=['esfera']

)
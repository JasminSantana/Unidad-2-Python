"""La primer función retorna el volumen de la esfera y la segunda el área de esta"""
'''Santana Mares Jasmin Aide GITI9071'''

from math import pi

def sphere_volume(r: float)->float:
    return (4/3)*(pi*(r**3))
def sphere_area(r: float)-> float:
    return 4*pi*(r**2)